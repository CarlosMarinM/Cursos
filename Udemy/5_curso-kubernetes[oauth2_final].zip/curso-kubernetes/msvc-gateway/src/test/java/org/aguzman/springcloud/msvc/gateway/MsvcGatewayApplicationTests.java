package org.aguzman.springcloud.msvc.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
