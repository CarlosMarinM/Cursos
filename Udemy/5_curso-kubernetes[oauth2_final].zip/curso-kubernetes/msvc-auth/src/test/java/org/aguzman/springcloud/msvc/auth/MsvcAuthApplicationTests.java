package org.aguzman.springcloud.msvc.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
